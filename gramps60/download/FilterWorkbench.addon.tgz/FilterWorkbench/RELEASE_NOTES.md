# FilterWorkbench (Filterværksted)
[GNU GPL (license)](LICENSE) • [ReadMe](README.md) • [Release Notes](RELEASE_NOTES.md)

