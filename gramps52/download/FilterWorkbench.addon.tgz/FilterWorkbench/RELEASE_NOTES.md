# FilterWorkbench (Filterværksted)
[Guide](GUIDE.md) • [ReadMe](README.md) • [Release Notes](RELEASE_NOTES.md) • [GNU GPL (license)](LICENSE)

