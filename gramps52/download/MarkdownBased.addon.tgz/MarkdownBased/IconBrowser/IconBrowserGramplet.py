# Gramps - a GTK+/GNOME based genealogy program
# Copyright (C) 2026 Brian McCullough
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""Icon Browser gramplet for the Gramps Dashboard.

Inventories every icon available in the current GTK / Gramps icon-theme cascade
(per the `freedesktop Icon Theme Specification`_) and presents them in a
two-pane browser.

Generated-by: Gemini 1.5 Pro / Ultra (Google, gemini-model-cascade, 2026-05)
"""

import logging
import gi
import os
import sys

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import GLib, Gdk, GdkPixbuf, Gtk, Pango

from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.plug import Gramplet

# ------------------------
# Gramps specific
# ------------------------
# MarkdownUtils lives one directory level above this plugin's folder.
_parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

try:
    from MarkdownUtils import (
        NAMESPACE_MAP,
        VIEW_NAMES,
        build_table_widget,
        define_tags,
        parse_markdown,
        resolve_icon_pixbuf,
    )

    _MARKDOWN_AVAILABLE = True
except ImportError:
    _MARKDOWN_AVAILABLE = False

try:
    _ = glocale.get_addon_translator(__file__).gettext
except (ValueError, AttributeError):
    _ = glocale.translation.gettext

LOG = logging.getLogger(__name__)

DETAIL_SIZES = [16, 22, 24, 32, 48, 64, 96, 128]
KNOWN_CONTEXTS = [
    "Actions",
    "Apps",
    "Categories",
    "Devices",
    "Emblems",
    "Emotes",
    "FileSystems",
    "International",
    "MimeTypes",
    "Places",
    "Status",
    "Stock",
]
THUMB_SIZE = 16

COL_PIXBUF = 0
COL_NAME = 1
COL_IN_THEME = 2
COL_CONTEXT = 3


def _esc(text):
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _load_pixbuf(icon_theme: Gtk.IconTheme, name: str, size: int):
    flags = Gtk.IconLookupFlags.GENERIC_FALLBACK | Gtk.IconLookupFlags.USE_BUILTIN
    try:
        return icon_theme.load_icon(name, size, flags)
    except Exception:
        return None


class IconBrowserGramplet(Gramplet):
    """Dashboard gramplet: live GTK/Gramps icon-theme browser."""

    def on_load(self):
        pass

    def on_unload(self):
        if getattr(self, "_theme_handler_id", None) is not None:
            try:
                settings = Gtk.Settings.get_default()
                if settings is not None:
                    settings.disconnect(self._theme_handler_id)
            except Exception:
                pass
        self._theme_handler_id = None

        if getattr(self, "_search_timeout_id", None) is not None:
            GLib.source_remove(self._search_timeout_id)
            self._search_timeout_id = None

        if getattr(self, "_idle_inspector_id", None) is not None:
            GLib.source_remove(self._idle_inspector_id)
            self._idle_inspector_id = None

    def init(self):
        gramps_sw = self.gui.get_container_widget()
        for child in gramps_sw.get_children():
            gramps_sw.remove(child)

        self._search_timeout_id = None
        self._idle_inspector_id = None

        inner_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        browser_content = self._build_browser_content()
        footer_box = self._build_footer()

        inner_vbox.pack_start(browser_content, True, True, 0)
        inner_vbox.pack_end(Gtk.Separator(), False, False, 0)
        inner_vbox.pack_end(footer_box, False, False, 0)

        gramps_sw.add(inner_vbox)
        self.gui.WIDGET = inner_vbox
        inner_vbox.show_all()

        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b".mono-text { font-family: monospace; }")
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

        settings = Gtk.Settings.get_default()
        if settings is not None:
            self._theme_handler_id = settings.connect(
                "notify::gtk-theme-name", self._on_theme_changed
            )
        else:
            self._theme_handler_id = None

        GLib.idle_add(self._initial_refresh_idle)

    def _initial_refresh_idle(self):
        self._refresh()
        return False

    def _build_footer(self):
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        footer.set_border_width(3)

        self._theme_label = Gtk.Label()
        self._theme_label.set_halign(Gtk.Align.START)
        self._theme_label.set_hexpand(True)
        self._theme_label.set_ellipsize(Pango.EllipsizeMode.END)
        footer.pack_start(self._theme_label, True, True, 0)

        self._count_label = Gtk.Label()
        self._count_label.set_halign(Gtk.Align.END)
        footer.pack_start(self._count_label, False, False, 0)

        refresh_btn = Gtk.Button()
        refresh_img = Gtk.Image.new_from_icon_name(
            "view-refresh", Gtk.IconSize.SMALL_TOOLBAR
        )
        refresh_btn.set_image(refresh_img)
        refresh_btn.set_relief(Gtk.ReliefStyle.NONE)
        refresh_btn.set_tooltip_text(_("Refresh icon inventory"))
        refresh_btn.connect("clicked", self._on_refresh_clicked)
        footer.pack_end(refresh_btn, False, False, 0)

        return footer

    def _build_browser_content(self):
        content_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        top_bar.set_border_width(4)
        top_bar.pack_start(Gtk.Label(label=_("Search:")), False, False, 0)

        self._search_entry = Gtk.SearchEntry()
        self._search_entry.set_placeholder_text(_("filter icon names…"))
        self._search_entry.set_hexpand(True)
        self._search_entry.connect("search-changed", self._on_search_changed)
        top_bar.pack_start(self._search_entry, True, True, 0)

        self._ctx_combo = Gtk.ComboBoxText()
        self._ctx_combo.append("*", _("All"))
        for ctx in KNOWN_CONTEXTS:
            self._ctx_combo.append(ctx, ctx)
        self._ctx_combo.append("Other", _("Other"))
        self._ctx_combo.set_active_id("*")
        self._ctx_combo.connect("changed", self._on_context_changed)
        top_bar.pack_start(self._ctx_combo, False, False, 0)

        content_vbox.pack_start(top_bar, False, False, 0)
        content_vbox.pack_start(Gtk.Separator(), False, False, 0)

        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)

        def _set_initial_split(widget, allocation):
            widget.set_position(allocation.width // 2)
            widget.disconnect(handler_id)

        handler_id = paned.connect("size-allocate", _set_initial_split)

        self._store = Gtk.ListStore(GdkPixbuf.Pixbuf, str, bool, str)
        self._filter = self._store.filter_new()
        self._filter.set_visible_func(self._row_visible)
        self._sort_model = Gtk.TreeModelSort(model=self._filter)

        self._tree = Gtk.TreeView(model=self._sort_model)
        self._tree.get_selection().connect("changed", self._on_selection_changed)

        rend_flag = Gtk.CellRendererText()
        col_flag = Gtk.TreeViewColumn("", rend_flag)
        col_flag.set_cell_data_func(rend_flag, self._render_flag_cell)
        col_flag.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
        col_flag.set_fixed_width(20)
        self._tree.append_column(col_flag)

        rend_pb = Gtk.CellRendererPixbuf()
        col_thumb = Gtk.TreeViewColumn("", rend_pb, pixbuf=COL_PIXBUF)
        col_thumb.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
        col_thumb.set_fixed_width(24)
        self._tree.append_column(col_thumb)

        rend_txt = Gtk.CellRendererText()
        col_name = Gtk.TreeViewColumn(_("Icon Name"), rend_txt, text=COL_NAME)
        col_name.set_sort_column_id(COL_NAME)
        col_name.set_expand(True)
        self._tree.append_column(col_name)

        list_sw = Gtk.ScrolledWindow()
        list_sw.add(self._tree)
        paned.pack1(list_sw, resize=True, shrink=False)

        detail_sw = Gtk.ScrolledWindow()
        self._detail_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self._detail_box.set_border_width(8)
        detail_sw.add(self._detail_box)
        paned.pack2(detail_sw, resize=True, shrink=False)

        content_vbox.pack_start(paned, True, True, 0)
        return content_vbox

    def _refresh(self):
        self._store.clear()
        self._clear_detail()

        icon_theme = Gtk.IconTheme.get_default()

        gtk_settings = Gtk.Settings.get_default()
        if gtk_settings:
            gtk_theme = gtk_settings.get_property("gtk-theme-name") or ""
            self._theme_label.set_markup(
                "<span foreground='#555555'><b>{}</b> {}</span>".format(
                    _("Theme:"), _esc(gtk_theme)
                )
            )

        all_names = icon_theme.list_icons(None) or []
        name_to_ctx = {}
        for ctx in KNOWN_CONTEXTS:
            for name in icon_theme.list_icons(ctx) or []:
                if name not in name_to_ctx:
                    name_to_ctx[name] = ctx

        theme_dirs = set(icon_theme.get_search_path() or [])

        for name in sorted(all_names, key=str.casefold):
            ctx = name_to_ctx.get(name, "Other")
            pb = _load_pixbuf(icon_theme, name, THUMB_SIZE)

            info = icon_theme.lookup_icon(name, 22, 0)
            in_theme = False
            if info is not None:
                fn = info.get_filename() or ""
                in_theme = any(fn.startswith(d) for d in theme_dirs)

            self._store.append([pb, name, in_theme, ctx])

        self._update_count_label()
        self._filter.refilter()
        GLib.idle_add(self._select_default_icon, "gramps-view")

    def _select_default_icon(self, target_name):
        if not self._tree or not self._sort_model:
            return False

        it = self._sort_model.get_iter_first()
        while it is not None:
            name = self._sort_model.get_value(it, COL_NAME)
            if name == target_name:
                path = self._sort_model.get_path(it)
                self._tree.get_selection().select_path(path)
                self._tree.scroll_to_cell(path, None, True, 0.5, 0.0)
                break
            it = self._sort_model.iter_next(it)
        return False

    def _row_visible(self, model, it, _data):
        name = model.get_value(it, COL_NAME) or ""
        ctx = model.get_value(it, COL_CONTEXT) or ""
        active_ctx = self._ctx_combo.get_active_id() or "*"
        if active_ctx != "*" and ctx != active_ctx:
            return False
        query = self._search_entry.get_text().strip().lower()
        return not query or query in name.lower()

    @staticmethod
    def _render_flag_cell(_col, renderer, model, it, _data):
        in_theme = model.get_value(it, COL_IN_THEME)
        renderer.set_property("foreground", "#006600" if in_theme else "#999999")
        renderer.set_property("text", "✓" if in_theme else "–")

    def _clear_detail(self):
        if getattr(self, "_idle_inspector_id", None) is not None:
            GLib.source_remove(self._idle_inspector_id)
            self._idle_inspector_id = None
        for child in self._detail_box.get_children():
            self._detail_box.remove(child)

    def _populate_detail(self, icon_name):
        self._clear_detail()
        icon_theme = Gtk.IconTheme.get_default()

        heading = Gtk.Label()
        heading.set_markup("<big><b>{}</b></big>".format(_esc(icon_name)))
        heading.set_halign(Gtk.Align.START)
        heading.set_selectable(True)
        self._detail_box.pack_start(heading, False, False, 0)

        strip_lbl = Gtk.Label()
        strip_lbl.set_markup("<b>{}</b>".format(_("Available sizes")))
        strip_lbl.set_halign(Gtk.Align.START)
        self._detail_box.pack_start(strip_lbl, False, False, 2)

        strip = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        strip.set_border_width(4)

        fallback_sizes = []
        self._current_available_sizes = []

        for px in DETAIL_SIZES:
            pb = _load_pixbuf(icon_theme, icon_name, px)
            if pb is None:
                continue

            info = icon_theme.lookup_icon(icon_name, px, Gtk.IconLookupFlags.USE_BUILTIN)
            is_native = False
            if info is not None:
                base = info.get_base_size()
                is_native = (base == px or base == 0)

            cell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            cell.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)

            colour = "#000000" if is_native else "#999999"
            size_lbl = Gtk.Label()
            size_lbl.set_markup("<span foreground='{}'>{}px</span>".format(colour, px))
            cell.pack_start(size_lbl, False, False, 0)
            strip.pack_start(cell, False, False, 4)

            if is_native:
                self._current_available_sizes.append(px)
            else:
                fallback_sizes.append(px)

        if not strip.get_children():
            missing = Gtk.Label(label=_("(icon not found in current theme)"))
            missing.set_halign(Gtk.Align.START)
            self._detail_box.pack_start(missing, False, False, 0)
            self._detail_box.show_all()
            return

        strip_sw = Gtk.ScrolledWindow()
        strip_sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        strip_sw.set_min_content_height(DETAIL_SIZES[-1] + 36)
        strip_sw.add(strip)
        self._detail_box.pack_start(strip_sw, False, False, 0)

        self._detail_box.pack_start(Gtk.Separator(), False, False, 4)

        info_main = icon_theme.lookup_icon(icon_name, 48, Gtk.IconLookupFlags.GENERIC_FALLBACK)
        if info_main is not None:
            filepath = info_main.get_filename() or ""
            theme_note = Gtk.Label()
            theme_note.set_markup("<span foreground='#555555'>{}</span>".format(_esc(filepath)))
            theme_note.set_halign(Gtk.Align.START)
            theme_note.set_line_wrap(True)
            theme_note.set_selectable(True)
            self._detail_box.pack_start(theme_note, False, False, 0)

        if fallback_sizes:
            fb_lbl = Gtk.Label()
            fb_lbl.set_markup(
                "<span foreground='#999999'>{}: {}</span>".format(
                    _("Scaled (not native)"),
                    ", ".join(str(size) for size in fallback_sizes),
                )
            )
            fb_lbl.set_halign(Gtk.Align.START)
            self._detail_box.pack_start(fb_lbl, False, False, 0)

        self._detail_box.pack_start(Gtk.Separator(), False, False, 4)

        md_heading = Gtk.Expander(label=_("MarkdownDash gramps:icon syntax"))
        md_heading.set_expanded(True)

        md_grid = Gtk.Grid()
        md_grid.set_column_spacing(8)
        md_grid.set_row_spacing(4)
        md_grid.set_border_width(4)

        scalable_syntax = f"![](gramps:icon:{icon_name})"
        scalable_lbl = Gtk.Label(label=scalable_syntax)
        scalable_lbl.set_halign(Gtk.Align.START)
        scalable_lbl.set_selectable(True)
        scalable_lbl.set_hexpand(True)
        scalable_lbl.get_style_context().add_class("mono-text")
        md_grid.attach(Gtk.Image(), 0, 0, 1, 1)
        md_grid.attach(scalable_lbl, 1, 0, 1, 1)

        scalable_copy = Gtk.Button()
        scalable_copy.set_image(Gtk.Image.new_from_icon_name("edit-copy", Gtk.IconSize.SMALL_TOOLBAR))
        scalable_copy.set_relief(Gtk.ReliefStyle.NONE)
        scalable_copy.set_tooltip_text(_("Copy scalable MarkdownDash syntax"))
        scalable_copy.connect("clicked", self._on_copy_syntax, scalable_syntax)
        md_grid.attach(scalable_copy, 2, 0, 1, 1)

        for row_idx, px in enumerate(self._current_available_sizes, start=1):
            pb = _load_pixbuf(icon_theme, icon_name, min(px, 32))
            md_grid.attach(Gtk.Image.new_from_pixbuf(pb) if pb else Gtk.Image(), 0, row_idx, 1, 1)

            syntax = f"![](gramps:icon:{icon_name}:{px})"
            src_lbl = Gtk.Label(label=syntax)
            src_lbl.set_halign(Gtk.Align.START)
            src_lbl.set_selectable(True)
            src_lbl.set_hexpand(True)
            src_lbl.get_style_context().add_class("mono-text")
            md_grid.attach(src_lbl, 1, row_idx, 1, 1)

            copy_btn = Gtk.Button()
            copy_btn.set_image(Gtk.Image.new_from_icon_name("edit-copy", Gtk.IconSize.SMALL_TOOLBAR))
            copy_btn.set_relief(Gtk.ReliefStyle.NONE)
            copy_btn.set_tooltip_text(_("Copy to clipboard"))
            copy_btn.connect("clicked", self._on_copy_syntax, syntax)
            md_grid.attach(copy_btn, 2, row_idx, 1, 1)

        md_heading.add(md_grid)
        self._detail_box.pack_start(md_heading, False, False, 0)

        self._detail_box.pack_start(Gtk.Separator(), False, False, 4)

        py_heading = Gtk.Expander(label=_("GTK button snippet"))
        py_heading.set_expanded(False)

        py_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        py_box.set_border_width(4)

        py_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)

        short_snippet = (
            "icon_img = Gtk.Image.new_from_icon_name(\n"
            f'    "{icon_name}", Gtk.IconSize.SMALL_TOOLBAR\n'
            ")\n"
        )

        full_snippet = (
            "icon_btn = Gtk.Button()\n"
            "icon_img = Gtk.Image.new_from_icon_name(\n"
            f'    "{icon_name}", Gtk.IconSize.SMALL_TOOLBAR\n'
            ")\n"
            "icon_btn.set_image(icon_img)\n"
            "icon_btn.set_relief(Gtk.ReliefStyle.NONE)\n"
            f'icon_btn.set_tooltip_text(_("{icon_name}"))\n'
            "icon_btn.connect(\"clicked\", self._on_icon_clicked)\n"
            "footer.pack_start(icon_btn, False, False, 0)\n"
        )

        short_copy_btn = Gtk.Button()
        short_copy_btn.set_image(Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.SMALL_TOOLBAR))
        short_copy_btn.set_relief(Gtk.ReliefStyle.NONE)
        short_copy_btn.set_tooltip_text(_("Copy short GTK snippet"))
        short_copy_btn.connect("clicked", self._on_copy_syntax, short_snippet)
        py_row.pack_start(short_copy_btn, False, False, 0)

        name_lbl = Gtk.Label(label=icon_name)
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.set_hexpand(True)
        name_lbl.set_selectable(True)
        py_row.pack_start(name_lbl, True, True, 0)

        full_copy_btn = Gtk.Button()
        full_copy_btn.set_image(Gtk.Image.new_from_icon_name("edit-copy", Gtk.IconSize.SMALL_TOOLBAR))
        full_copy_btn.set_relief(Gtk.ReliefStyle.NONE)
        full_copy_btn.set_tooltip_text(_("Copy snippet"))
        full_copy_btn.connect("clicked", self._on_copy_syntax, full_snippet)
        py_row.pack_start(full_copy_btn, False, False, 0)

        py_box.pack_start(py_row, False, False, 0)
        py_heading.add(py_box)
        self._detail_box.pack_start(py_heading, False, False, 0)

        self._detail_box.show_all()

        # DEFER PATH INSPECTOR GENERATION TO IDLE PROCESS TO REMOVE SELECTION STUTTER
        self._idle_inspector_id = GLib.idle_add(self._deferred_populate_inspector, icon_name)

    def _deferred_populate_inspector(self, icon_name):
        self._idle_inspector_id = None
        icon_theme = Gtk.IconTheme.get_default()

        # Build fallback layout cascade stack
        parts = icon_name.split("-")
        cascade_names = []
        for i in range(len(parts), 0, -1):
            cascade_names.append("-".join(parts[:i]))

        # Add Explicit Symbolic Checks & True Structural Missing Asset Fallback
        if not icon_name.endswith("-symbolic"):
            cascade_names.append(f"{icon_name}-symbolic")
        if "image-missing" not in cascade_names:
            cascade_names.append("image-missing")

        sep = Gtk.Separator()
        path_heading = Gtk.Expander(label=_("GTK Path Inspector"))
        path_heading.set_expanded(False)

        path_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        path_box.set_border_width(4)

        inspector_grid = Gtk.Grid()
        inspector_grid.set_column_spacing(12)
        inspector_grid.set_row_spacing(6)

        lbl_h_name = Gtk.Label()
        lbl_h_name.set_markup("<b>Fallback Name</b>")
        lbl_h_name.set_halign(Gtk.Align.START)
        inspector_grid.attach(lbl_h_name, 0, 0, 1, 1)

        lbl_h_preview = Gtk.Label()
        lbl_h_preview.set_markup("<b>Preview</b>")
        lbl_h_preview.set_halign(Gtk.Align.CENTER)
        inspector_grid.attach(lbl_h_preview, 1, 0, 1, 1)

        lbl_h_path = Gtk.Label()
        lbl_h_path.set_markup("<b>Resolved Absolute Path</b>")
        lbl_h_path.set_halign(Gtk.Align.START)
        inspector_grid.attach(lbl_h_path, 2, 0, 1, 1)

        target_sizes = [24, 22, 16]

        for idx, current_name in enumerate(cascade_names, start=1):
            name_lbl = Gtk.Label(label=current_name)
            name_lbl.set_halign(Gtk.Align.START)
            name_lbl.get_style_context().add_class("mono-text")
            inspector_grid.attach(name_lbl, 0, idx, 1, 1)

            resolved_info = None
            chosen_size = 24
            for size in target_sizes:
                info_check = icon_theme.lookup_icon(current_name, size, Gtk.IconLookupFlags.USE_BUILTIN)
                if info_check is not None:
                    resolved_info = info_check
                    chosen_size = size
                    break

            img_widget = Gtk.Image()
            if resolved_info is not None:
                pb = _load_pixbuf(icon_theme, current_name, chosen_size)
                if pb:
                    img_widget.set_from_pixbuf(pb)
            else:
                img_widget.set_from_icon_name("dialog-error", Gtk.IconSize.MENU)
            inspector_grid.attach(img_widget, 1, idx, 1, 1)

            path_lbl = Gtk.Label()
            path_lbl.set_halign(Gtk.Align.START)
            path_lbl.set_selectable(True)
            path_lbl.set_line_wrap(True)

            if resolved_info is not None:
                f_path = resolved_info.get_filename() or _("(Built-in binary resource)")
                if current_name == icon_name:
                    path_lbl.set_markup(f"<span foreground='#006600'><b>{_esc(f_path)}</b></span>")
                elif "missing" in current_name:
                    path_lbl.set_markup(f"<span foreground='#AA0000'><i>{_esc(f_path)}</i></span>")
                else:
                    path_lbl.set_markup(f"<span foreground='#555555'>{_esc(f_path)}</span>")
            else:
                path_lbl.set_markup(f"<span foreground='#999999'><i>{_('Not found in active themes')}</i></span>")

            inspector_grid.attach(path_lbl, 2, idx, 1, 1)

        path_box.pack_start(inspector_grid, False, False, 0)
        path_heading.add(path_box)

        self._detail_box.pack_start(sep, False, False, 4)
        self._detail_box.pack_start(path_heading, False, False, 0)
        self._detail_box.show_all()
        return False

    def _on_selection_changed(self, selection):
        model, it = selection.get_selected()
        if it:
            self._populate_detail(model.get_value(it, COL_NAME))

    def _on_search_changed(self, _widget):
        if getattr(self, "_search_timeout_id", None) is not None:
            GLib.source_remove(self._search_timeout_id)
        self._search_timeout_id = GLib.timeout_add(500, self._do_search_filter)

    def _do_search_filter(self):
        self._search_timeout_id = None
        self._filter.refilter()
        self._update_count_label()
        return False

    def _on_context_changed(self, _widget):
        self._filter.refilter()
        self._update_count_label()

    def _on_refresh_clicked(self, _widget):
        GLib.idle_add(self._initial_refresh_idle)

    def _on_theme_changed(self, _settings, _param):
        GLib.timeout_add(300, self._deferred_refresh)

    def _deferred_refresh(self):
        GLib.idle_add(self._initial_refresh_idle)
        return False

    def _on_copy_syntax(self, _widget, syntax):
        cb = Gtk.Clipboard.get_default(self.uistate.window.get_display())
        cb.set_text(syntax, -1)

    def _update_count_label(self):
        visible = sum(1 for row in self._store if self._row_visible(self._store, row.iter, None))
        self._count_label.set_markup("{} of {} icons".format(visible, len(self._store)))

    def main(self):
        pass